<?php
/**
 * Generic theme sidebar
 *
 * @package Layers
 * @since Layers 1.0.0
 */

dynamic_sidebar( LAYERS_THEME_SLUG . '-sidebar' );